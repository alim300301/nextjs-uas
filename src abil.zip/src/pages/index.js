import { useEffect, useState } from "react";
import Link from "next/link";

export default function Home() {
  const [motors, setMotors] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMotors = async () => {
      try {
        const res = await fetch("http://localhost:1337/api/data-sepeda-motors");
        const result = await res.json();

        if (result && result.data) {
          setMotors(result.data);
        } else {
          setError("No data available.");
        }
      } catch (err) {
        setError("Failed to fetch data.");
        console.error(err);
      }
    };

    fetchMotors();
  }, []);

  if (error) return <div>{error}</div>;

  return (
    <div style={{ backgroundColor: "black", color: "white" }}>
      <h1>Daftar Sepeda Motor yang dapat disewa</h1>
      <table border="3" style={{ width: "70%", marginBottom: "60px", textAlign: "left" }}>
        <thead>
          <tr>
            <th style={{ width: "5%" }}>ID</th>
            <th style={{ width: "50%" }}>Jenis Motor</th>
            <th style={{ width: "20%" }}>Harga Motor</th>
            <th style={{ width: "20%" }}>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {motors.map((motor) => (
            <tr key={motor.id}>
              <td>{motor.id}</td>
              <td>{motor.Jenis_motor}</td>
              <td>{motor.Harga_motor}</td>
              <td>
                <Link href={`/FormPengajuan?id=${motor.id}`}>
                  <button style={{ padding: "5px 10px", backgroundColor: "green", color: "white" }}>
                    Ajukan Kredit
                  </button>
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}